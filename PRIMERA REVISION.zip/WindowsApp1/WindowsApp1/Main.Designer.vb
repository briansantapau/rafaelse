﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class form_main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(form_main))
        Me.btn_lista_cliente = New System.Windows.Forms.Button()
        Me.btn_anadir_clientes = New System.Windows.Forms.Button()
        Me.btn_eliminar_clientes = New System.Windows.Forms.Button()
        Me.btn_opciones = New System.Windows.Forms.Button()
        Me.btn_salir = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.radio_ape_az = New System.Windows.Forms.RadioButton()
        Me.radio_ape_za = New System.Windows.Forms.RadioButton()
        Me.radio_nombre_za = New System.Windows.Forms.RadioButton()
        Me.radio_nombre_az = New System.Windows.Forms.RadioButton()
        Me.radio_oh_mayor = New System.Windows.Forms.RadioButton()
        Me.radio_oh_menor = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.radio_ttl_myor = New System.Windows.Forms.RadioButton()
        Me.radio_ttl_comp_mnr = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.label5 = New System.Windows.Forms.Label()
        Me.la = New System.IO.FileSystemWatcher()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.btn = New System.Windows.Forms.Button()
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.ServiceController1 = New System.ServiceProcess.ServiceController()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.btn_crear_nueva_orden = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.la, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_lista_cliente
        '
        Me.btn_lista_cliente.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btn_lista_cliente, "btn_lista_cliente")
        Me.btn_lista_cliente.Name = "btn_lista_cliente"
        Me.btn_lista_cliente.UseVisualStyleBackColor = True
        '
        'btn_anadir_clientes
        '
        Me.btn_anadir_clientes.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btn_anadir_clientes, "btn_anadir_clientes")
        Me.btn_anadir_clientes.Name = "btn_anadir_clientes"
        Me.btn_anadir_clientes.UseVisualStyleBackColor = True
        '
        'btn_eliminar_clientes
        '
        Me.btn_eliminar_clientes.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btn_eliminar_clientes, "btn_eliminar_clientes")
        Me.btn_eliminar_clientes.Name = "btn_eliminar_clientes"
        Me.btn_eliminar_clientes.UseVisualStyleBackColor = True
        '
        'btn_opciones
        '
        Me.btn_opciones.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btn_opciones, "btn_opciones")
        Me.btn_opciones.Name = "btn_opciones"
        Me.btn_opciones.UseVisualStyleBackColor = True
        '
        'btn_salir
        '
        Me.btn_salir.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btn_salir, "btn_salir")
        Me.btn_salir.Name = "btn_salir"
        Me.btn_salir.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        resources.ApplyResources(Me.DataGridView1, "DataGridView1")
        Me.DataGridView1.Name = "DataGridView1"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        resources.ApplyResources(Me.PictureBox1, "PictureBox1")
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        resources.ApplyResources(Me.Panel1, "Panel1")
        Me.Panel1.Controls.Add(Me.btn_crear_nueva_orden)
        Me.Panel1.Controls.Add(Me.btn_lista_cliente)
        Me.Panel1.Controls.Add(Me.btn_anadir_clientes)
        Me.Panel1.Controls.Add(Me.btn_eliminar_clientes)
        Me.Panel1.Controls.Add(Me.btn_salir)
        Me.Panel1.Controls.Add(Me.btn_opciones)
        Me.Panel1.Name = "Panel1"
        '
        'radio_ape_az
        '
        resources.ApplyResources(Me.radio_ape_az, "radio_ape_az")
        Me.radio_ape_az.Name = "radio_ape_az"
        Me.radio_ape_az.TabStop = True
        Me.radio_ape_az.UseVisualStyleBackColor = True
        '
        'radio_ape_za
        '
        resources.ApplyResources(Me.radio_ape_za, "radio_ape_za")
        Me.radio_ape_za.Name = "radio_ape_za"
        Me.radio_ape_za.TabStop = True
        Me.radio_ape_za.UseVisualStyleBackColor = True
        '
        'radio_nombre_za
        '
        resources.ApplyResources(Me.radio_nombre_za, "radio_nombre_za")
        Me.radio_nombre_za.Checked = True
        Me.radio_nombre_za.Name = "radio_nombre_za"
        Me.radio_nombre_za.TabStop = True
        Me.radio_nombre_za.UseVisualStyleBackColor = True
        '
        'radio_nombre_az
        '
        resources.ApplyResources(Me.radio_nombre_az, "radio_nombre_az")
        Me.radio_nombre_az.Name = "radio_nombre_az"
        Me.radio_nombre_az.UseVisualStyleBackColor = True
        '
        'radio_oh_mayor
        '
        resources.ApplyResources(Me.radio_oh_mayor, "radio_oh_mayor")
        Me.radio_oh_mayor.Name = "radio_oh_mayor"
        Me.radio_oh_mayor.TabStop = True
        Me.radio_oh_mayor.UseVisualStyleBackColor = True
        '
        'radio_oh_menor
        '
        resources.ApplyResources(Me.radio_oh_menor, "radio_oh_menor")
        Me.radio_oh_menor.Name = "radio_oh_menor"
        Me.radio_oh_menor.TabStop = True
        Me.radio_oh_menor.UseVisualStyleBackColor = True
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'radio_ttl_myor
        '
        resources.ApplyResources(Me.radio_ttl_myor, "radio_ttl_myor")
        Me.radio_ttl_myor.Name = "radio_ttl_myor"
        Me.radio_ttl_myor.TabStop = True
        Me.radio_ttl_myor.UseVisualStyleBackColor = True
        '
        'radio_ttl_comp_mnr
        '
        resources.ApplyResources(Me.radio_ttl_comp_mnr, "radio_ttl_comp_mnr")
        Me.radio_ttl_comp_mnr.Name = "radio_ttl_comp_mnr"
        Me.radio_ttl_comp_mnr.TabStop = True
        Me.radio_ttl_comp_mnr.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radio_ape_az)
        Me.GroupBox1.Controls.Add(Me.radio_ape_za)
        Me.GroupBox1.Controls.Add(Me.Label3)
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.radio_ttl_myor)
        Me.GroupBox2.Controls.Add(Me.radio_ttl_comp_mnr)
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.radio_oh_mayor)
        Me.GroupBox3.Controls.Add(Me.radio_oh_menor)
        resources.ApplyResources(Me.GroupBox3, "GroupBox3")
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.radio_nombre_za)
        Me.GroupBox4.Controls.Add(Me.radio_nombre_az)
        resources.ApplyResources(Me.GroupBox4, "GroupBox4")
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.TabStop = False
        '
        'Button6
        '
        Me.Button6.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.Button6, "Button6")
        Me.Button6.Name = "Button6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'label5
        '
        resources.ApplyResources(Me.label5, "label5")
        Me.label5.Name = "label5"
        '
        'la
        '
        Me.la.EnableRaisingEvents = True
        Me.la.SynchronizingObject = Me
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'FileSystemWatcher1
        '
        Me.FileSystemWatcher1.EnableRaisingEvents = True
        Me.FileSystemWatcher1.SynchronizingObject = Me
        '
        'TextBox1
        '
        resources.ApplyResources(Me.TextBox1, "TextBox1")
        Me.TextBox1.Name = "TextBox1"
        '
        'btn
        '
        Me.btn.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.btn, "btn")
        Me.btn.Name = "btn"
        Me.btn.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        resources.ApplyResources(Me.TextBox2, "TextBox2")
        Me.TextBox2.Name = "TextBox2"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Name = "Label8"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'TextBox3
        '
        resources.ApplyResources(Me.TextBox3, "TextBox3")
        Me.TextBox3.Name = "TextBox3"
        '
        'Button7
        '
        Me.Button7.Cursor = System.Windows.Forms.Cursors.Hand
        resources.ApplyResources(Me.Button7, "Button7")
        Me.Button7.Name = "Button7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'btn_crear_nueva_orden
        '
        resources.ApplyResources(Me.btn_crear_nueva_orden, "btn_crear_nueva_orden")
        Me.btn_crear_nueva_orden.Name = "btn_crear_nueva_orden"
        Me.btn_crear_nueva_orden.UseVisualStyleBackColor = True
        '
        'form_main
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.btn)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "form_main"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.la, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_lista_cliente As Button
    Friend WithEvents btn_anadir_clientes As Button
    Friend WithEvents btn_eliminar_clientes As Button
    Friend WithEvents btn_opciones As Button
    Friend WithEvents btn_salir As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents Panel1 As Panel
    Friend WithEvents radio_ape_az As RadioButton
    Friend WithEvents radio_ape_za As RadioButton
    Friend WithEvents radio_nombre_za As RadioButton
    Friend WithEvents radio_nombre_az As RadioButton
    Friend WithEvents radio_oh_mayor As RadioButton
    Friend WithEvents radio_oh_menor As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents radio_ttl_myor As RadioButton
    Friend WithEvents radio_ttl_comp_mnr As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Button6 As Button
    Friend WithEvents label5 As Label
    Friend WithEvents la As IO.FileSystemWatcher
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents btn As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents FileSystemWatcher1 As IO.FileSystemWatcher
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents ServiceController1 As ServiceProcess.ServiceController
    Friend WithEvents Button7 As Button
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents btn_crear_nueva_orden As Button
End Class
